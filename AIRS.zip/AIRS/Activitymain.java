package com.example.airs;
import static android.Manifest.permission.SEND_SMS;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText txtMobile, txtName, txtRollNo, txtYear, txtDate, txtMessage;
    Button btnSms, btnAddRecord, btnViewRecords;
    DatabaseHelper dbHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize UI Elements
        txtName = findViewById(R.id.nameInput);
        txtRollNo = findViewById(R.id.rollNoInput);
        txtYear = findViewById(R.id.yearInput);
        txtDate = findViewById(R.id.dateInput);
        txtMobile = findViewById(R.id.mobInput);
        txtMessage = findViewById(R.id.msgTxt);
        btnSms = findViewById(R.id.btnSend);
        btnAddRecord = findViewById(R.id.btnAddRecord);
        btnViewRecords = findViewById(R.id.btnViewRecords);
        // Initialize Database Helper
        dbHelper = new DatabaseHelper(this);

        // Add Record Button Click
        btnAddRecord.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                addRecord();
            }
        });

        // View Records Button Click
        btnViewRecords.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewRecords();
            }
        });

        // Send SMS Button Click
        btnSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                sendSMS();
            }
        });
    }

    // Method to Add Record to SQLite Database
    private void addRecord() {
        String name = txtName.getText().toString();
        String rollNo = txtRollNo.getText().toString();
        String year = txtYear.getText().toString();
        String date = txtDate.getText().toString();
        String mobile = txtMobile.getText().toString();
        String message = txtMessage.getText().toString();
        if (name.isEmpty() || rollNo.isEmpty() || year.isEmpty() || date.isEmpty() ||       mobile.isEmpty()) {
            Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            return;
        }
        boolean isInserted = dbHelper.insertData(name, rollNo, year, date, mobile, message);
        if (isInserted) {
            Toast.makeText(this, "Record Added Successfully", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to Add Record", Toast.LENGTH_SHORT).show();
        }
    }

    // Method to View Records
    private void viewRecords() {
        Intent intent = new Intent(MainActivity.this, ViewRecordsActivity.class);
        startActivity(intent);
    }

    // Method to Send SMS
    private void sendSMS() {
        if (ContextCompat.checkSelfPermission(MainActivity.this, SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            try {
                String number = txtMobile.getText().toString();
                String name = txtName.getText().toString();
                String rollNo = txtRollNo.getText().toString();
                String year = txtYear.getText().toString();
                String date = txtDate.getText().toString();
                String message = txtMessage.getText().toString();
                String msg = "Your child " + name + " (Roll No: " + rollNo + ", Year: " + year + “)     was absent on " + date + ". " + message;
                SmsManager smsManager = SmsManager.getDefault();
                smsManager.sendTextMessage(number, null, msg, null, null);
                Toast.makeText(MainActivity.this, "SMS Sent Successfully", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "SMS Failed to Send, Please try again", Toast.LENGTH_SHORT).show();
            }
        } else {
            ActivityCompat.requestPermissions(MainActivity.this, new String[]{SEND_SMS}, 100);
            Toast.makeText(MainActivity.this, "Permission not granted", Toast.LENGTH_SHORT).show();
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            btnSms.performClick();
        }
    }
}



