package com.example.airs;
import android.annotation.SuppressLint;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class ViewRecordsActivity extends AppCompatActivity {
    DatabaseHelper dbHelper;
    TextView recordsText;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_records);

        recordsText = findViewById(R.id.btnAddRecord);
        dbHelper = new DatabaseHelper(this);
        recordsText = findViewById(R.id.btnViewRecords);
        dbHelper = new DatabaseHelper(this);

        Cursor cursor = dbHelper.getAllRecords();
        StringBuilder records = new StringBuilder();

        if (cursor.getCount() == 0) {
            recordsText.setText("No Records Found");
            return;
        }



        while (cursor.moveToNext()) {
            records.append("Name: ").append(cursor.getString(1)).append("\n");
            records.append("Roll No: ").append(cursor.getString(2)).append("\n");
            records.append("Year: ").append(cursor.getString(3)).append("\n");
            records.append("Date: ").append(cursor.getString(4)).append("\n");
            records.append("Mobile: ").append(cursor.getString(5)).append("\n");
            records.append("Message: ").append(cursor.getString(6)).append("\n\n");
        }

        recordsText.setText(records.toString());
    }
}

